<!DOCTYPE html>
<!--	Author:
		Date:
		File: city-trip.php
		Purpose: Chapter 11 Exercise
-->

<html>
<head>
	<title>City Trip</title>
	<link rel ="stylesheet" type="text/css" href="sample.css">
</head>

<body>
	<?php
	
		// Add your code here		
	?>

</body>
</html>
