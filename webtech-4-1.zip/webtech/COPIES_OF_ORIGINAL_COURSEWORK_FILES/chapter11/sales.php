<!DOCTYPE html>
<!--Author:
	Date:
	File:	  sales.php 
	Purpose:

-->

<html>
<head>
	<title>Sales Report</title>
	<link rel ="stylesheet" type="text/css" href="sample.css">
</head>
<body>
	<?php

		
	?>
</body>
</html>
