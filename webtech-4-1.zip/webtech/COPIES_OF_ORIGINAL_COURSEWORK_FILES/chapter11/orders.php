<!DOCTYPE html>
<!--Author:
	Date:
	File:	  orders.php
	Purpose:
	
-->

<html>
<head>
	<title>BLUEBERRY ORDERS</title>
	<link rel ="stylesheet" type="text/css" href="sample.css">
</head>
<body>

	<?php
		
		print ("<h1>BLUEBERRY ORDERS</h1>");
		print ("<table border = \"1\">");
		print ("<tr><th>Order #</th><th>Quantity</th></tr>");
		
		
		print ("</table>");
		


		print ("<p>TOTAL NUMBER OF BUSHES ORDERED: $totalBushes.</p>");
		print ("<p>TOTAL NUMBER OF ORDERS: ".sizeof($orders).".</p>");		
	?>
</body>
</html>
