<!DOCTYPE html>
<!--Author:
	Date:
	File:	submit-order.php
	Purpose:Chapter 6 Exercise

-->

<html>
<head>
	<title>SaveTheWorld Software</title>
	<link rel ="stylesheet" type="text/css" href="sample.css">
</head>
<body>

	<h1>SaveTheWorld: Submission Results</h1>

	<?php



		print("<p>Your order had been received and will be processed shortly");
	?>

</body>
</html>
