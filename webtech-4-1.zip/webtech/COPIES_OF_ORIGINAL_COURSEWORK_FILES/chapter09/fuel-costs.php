<!DOCTYPE html>
<!--	Author:
		Date:
		File:	fuel-costs.php
		Purpose: Chapter 9 Exercise
-->

<html>
<head>
	<title>Fuel Cost Calculator</title>
	<link rel ="stylesheet" type="text/css" href="sample.css">
</head>

<body>
	<?php
		$carMake = $_POST['carMake'];
		$carModel = $_POST['carModel'];		
		$mpg = $_POST['mpg'];
		$costPerGallon = $_POST['costPerGallon'];
		
		// Add a table here that uses a FOR loop to display the fuel costs
		// for 10,000 to 100,000 miles of travel in 10,000 mile increments
		// See instructions in the textbook for details.
	

		
			
	?>

</body>
</html>
