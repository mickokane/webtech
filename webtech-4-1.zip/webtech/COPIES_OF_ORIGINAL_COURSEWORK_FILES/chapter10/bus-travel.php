<!DOCTYPE html>
<!--	Author:
		Date:
		File:	bus-travel.php
		Purpose: Chapter 10 Exercise

-->

<html>
<head>
	<title>BUSINESS TRAVEL</title>
	<link rel ="stylesheet" type="text/css" href="sample.css">
</head>

<body>
	<?php
	
		// Add your code here to meet the requirements of this exercise
	
		
		
		
		
						
		print ("<h1>BUSINESS TRAVEL REIMBURSEMENT SUMMARY</h1>");
		print("<p>Your total reimbursement for this period is $".number_format($grandTotal, 2)."</p>");
	?>

</body>
</html>
