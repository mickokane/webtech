<!DOCTYPE html>
<!--	Author:
		Date:
		File:	events.php
		Purpose: Chapter 10 Exercise
-->

<html>
<head>
	<title>Events List</title>
	<link rel ="stylesheet" type="text/css" href="sample.css">
</head>

<body>
	<?php
		print("<h1>LIST OF EVENTS</h1>");

			
		// Add your code here to meet the requirements of this exercise
	
?>
</body>
</html>
