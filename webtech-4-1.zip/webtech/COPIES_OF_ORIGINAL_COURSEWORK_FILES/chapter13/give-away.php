<!DOCTYPE html>
<!--Author:
	Date:
	File:	  give-away.php
	Purpose:

-->

<html>
<head>
	<title>GIVE AWAY</title>
	<link rel ="stylesheet" type="text/css" href="sample.css">
</head>
<body>

	<?php

	  // add the freeTrip function here
		
		print ("<h1>CONGRATULATIONS!</h1>");

		$destination = ; // call the freeTrip function here

		print ("<h1>You have won a free trip to $destination!!!</h1>");


	?>
</body>
</html>
