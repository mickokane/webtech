<!DOCTYPE html>
<!--	Author:
		Date:
		File:	event.php
		Purpose: Chapter 5 Exercise

-->

<html>
<head>
	<title>Performance</title>
	<link rel ="stylesheet" type="text/css" href="sample.css">
</head>

<body>
	<?php

	?>

</body>
</html>
