<!DOCTYPE html>
<!--	Author:
		Date:
		File:	fuel-cost.php
		Purpose: Chapter 5 Exercise
-->

<html>
<head>
	<title>Fuel Cost Calculator</title>
	<link rel ="stylesheet" type="text/css" href="sample.css">
</head>

<body>
	<?php

	?>

</body>
</html>
