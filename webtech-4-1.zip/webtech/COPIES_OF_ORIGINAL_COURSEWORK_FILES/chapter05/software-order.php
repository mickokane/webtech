<!DOCTYPE html>
<!--Author:
	Date:
	File:	software-order.php
	Purpose:Chapter 5 Exercise

-->


<html>
<head>
	<title>SaveTheWorld Software</title>
	<link rel ="stylesheet" type="text/css" href="sample.css">
</head>
<body>

	<h1>Your Order</h1>

	<?php


	?>

</body>
</html>
