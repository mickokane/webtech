<!DOCTYPE html>
<!--Author:
	Date:
	File:	paint-estimate.php
	Purpose:Chapter 5 Exercise

-->


<html>
<head>
	<title>King Painting</title>
	<link rel ="stylesheet" type="text/css" href="sample.css">
</head>
<body>

	<h1>King Painting: Paint Estimate</h1>

	<?php


	?>

</body>
</html>
