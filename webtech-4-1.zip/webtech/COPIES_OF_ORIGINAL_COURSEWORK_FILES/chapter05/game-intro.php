<!DOCTYPE html>
<!--Author:
	Date:
	File:	game-intro.php
	Purpose:Chapter 5 Exercise

-->


<html>
<head>
	<title>gameIntro</title>
	<link rel ="stylesheet" type="text/css" href="sample.css">
</head>
<body>

	<?php


	?>

</body>
</html>
