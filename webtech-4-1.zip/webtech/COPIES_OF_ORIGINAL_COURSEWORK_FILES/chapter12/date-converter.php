<!DOCTYPE html>
<!--	
	Author:
	Date:
	File:    date-converter.php
	Purpose: Chapter 12 Exercise
-->

<html>
<head>
	<title>City Trip</title>
	<link rel ="stylesheet" type="text/css" href="sample.css">
</head>

<body>
	<?php
		$monthNumbers = array('January'=>1, 'February'=>1, 'March'=>3, 'April'=>4, 
				     'May'=>5, 'June'=>6, 'July'=>7, 'August'=>8, 
				     'September'=>9, 'October'=>10, 'November'=>11, 'December'=>12);

		$dayNum = $_POST['dayNum'];
		$month = $_POST['month'];		
		$year = $_POST['year'];
		
		// Add your print statement here

	?>

</body>
</html>
