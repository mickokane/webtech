<!DOCTYPE html>
<!--Author:
	Date:
	File:	 my-info.php
	Purpose: Chapter 12 Exercise
	
-->

<html>
<head>
	<title>My Address</title>
	<link rel ="stylesheet" type="text/css" href="sample.css">
</head>
<body>

	<?php		

		
	?>
</body>
</html>
