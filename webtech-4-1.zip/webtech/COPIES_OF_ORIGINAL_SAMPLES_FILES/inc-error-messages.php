<?php
$errorMessage ['badLoginID'] = "ERROR: Your Login ID does not match our records.";
$errorMessage ['badPassword'] = "ERROR: Your Password does not match our records.";
$errorMessage ['wrongAccessLevel'] = "ERROR: YOu do not have authority to access that resource.";
$errorMessage ['emptyFile'] = "ERROR: The file was empty";
$errorMessage ['fileNotFound'] = "ERROR: The file could not be found in that location.";
$errorMessage ['fileOpen'] = "ERROR: There was a problem opening the file.";
$errorMessage ['badFileName'] = "ERROR: That is not a valid file name.";
?>
