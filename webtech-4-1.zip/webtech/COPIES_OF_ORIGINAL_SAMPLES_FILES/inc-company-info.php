<?php
$companyInfo ['name'] = "Most Excellent Web Design, Inc.";
$companyInfo ['street'] = "123 Main Street";
$companyInfo ['city'] = "Sometown";
$companyInfo ['state'] = "SomeState";
$companyInfo ['zip'] = "12345";
$companyInfo ['email'] = "webmaster@mewd.com";
$companyInfo ['phone'] = "(123) 456-7890";
$companyInfo ['fax'] = "(098) 765-4321";
?>
