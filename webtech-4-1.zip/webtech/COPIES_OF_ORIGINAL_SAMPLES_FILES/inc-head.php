<!DOCTYPE html>
<!--	Author: 	Mike O'Kane
		Date:		August 15, 2007
		File:		inc-head.php
		Purpose: 	Example of include files to store HTML code and functions
-->
<html>
<head>
	<title>SALES REPORT</title>
	<link rel ="stylesheet" type="text/css" href="sales-report.css">
</head>
<body>
