<?php
$server = "localhost";
$user = "wbip";
$pw = "wbip123";
$db = "test";
?>
